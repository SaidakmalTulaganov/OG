from .models import Firm
from django.forms import ModelForm, TextInput


class FirmForm(ModelForm):
    class Meta:
        model = Firm
        fields = ["title", "country"]
        widgets = {
            "title": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите название'
            }),
            "country": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите страну производителя'
            })
        }
