from django.contrib import admin
from .models import Firm

admin.site.register(Firm)
