from django.shortcuts import render, redirect
from .models import Firm
from .forms import FirmForm


def index(request):
    firms = Firm.objects.order_by('-id')
    return render(request, 'main/index.html', {'title': 'Главная страница сайта', 'firms': firms})


def cart(request):
    return render(request, 'main/cart.html')


def signin(request):
    return render(request, 'main/signin.html')


def favorites(request):
    return render(request, 'main/favorites.html')


def create_firm(request):
    error = ''
    if request.method == 'POST':
        form = FirmForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('glagnaya')
        else:
            error = 'Форма была неверной!'

    form = FirmForm()
    context = {
        'form': form,
        'error': error
    }
    return render(request, 'main/create_firm.html', context)
