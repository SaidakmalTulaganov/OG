from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='glagnaya'),
    path('sign-in', views.signin, name='avtorizaciya'),
    path('cart', views.cart, name='korzina'),
    path('favorites', views.favorites, name='izbrannoe'),
    path('create_firm', views.create_firm, name='firms')
]
